from django.apps import AppConfig


class MyblogConfig(AppConfig):
    name = 'myblog'
